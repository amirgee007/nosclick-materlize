
<br>
<div class="row">
    <div class="col-md-7 col-md-offset-3">
        <div class="card">
            <div class="card-content content-info">
                <h3 class="category-social text-center">
                    <i class="fa fa-twitter"></i> Up Coming News
                </h3>
                <h4 class="card-title">
                    <h5> "Hi, All of my valuable client. Sorry for delay reply. I was in vacation. Now, I'm back to work. So, You don’t have to worry about support. I will support you any time. If you have need support for installation I will help you just email me. This time I will do without delay. I have made a cool update of this version. I already submitted to CodeCanyon. It will be live soon. However, New update has many features" </h5>

                </h4>

            </div>
            <br>
            <div class="card-content content-danger">
                <h4 class="card-content"> Note: We are Increasing Our Script Price After Release Update. So, If You Want to Discount Then Buy Now This Script Before Releasing Update. Otherwise You have to Buy This Script in High Price. This is the Great Time to Save Your Money. Thanks for Visiting This Page. Have a Great Time..! </h4>
            </div>
        </div>

    </div>

</div>