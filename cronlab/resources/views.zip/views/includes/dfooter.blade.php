<div class="container-fluid">
    <nav class="pull-left">
        <ul>
         
    </nav>
    <p class="copyright pull-right">
        &copy; {{config('app.name')}} {{ date('Y') }}</a>
    </p>
</div>